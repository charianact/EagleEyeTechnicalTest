﻿using MovieAPI.Model;
using TinyCsvParser.Mapping;

namespace MovieAPI.Maps
{
    public class StatMap : CsvMapping<Stat>
    {
        public StatMap() : base()
        {
            MapProperty(0, x => x.MovieId);
            MapProperty(1, x => x.WatchDurationMs);
        }
    }
}
