﻿using MovieAPI.Model;
using TinyCsvParser.Mapping;

namespace MovieAPI.Maps
{
    public class MovieMap : CsvMapping<Movie>
    {
        public MovieMap() : base()
        {
            MapProperty(0, x => x.ID);
            MapProperty(1, x => x.MovieId);
            MapProperty(2, x => x.Title);
            MapProperty(3, x => x.Language);
            MapProperty(4, x => x.Duration);
            MapProperty(5, x => x.ReleaseYear);
        }
    }
}
