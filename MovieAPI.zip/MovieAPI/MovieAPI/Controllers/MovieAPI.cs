﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MovieAPI.Maps;
using MovieAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using TinyCsvParser;

namespace MovieAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [Produces("application/json")]
    public class MovieAPI : ControllerBase
    {
        public MovieAPI(ILogger<MovieAPI> logger)
        {
        }

        [HttpPost]
        public void Post(string movieJson)
        {
            var options = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

            var movie = JsonSerializer.Deserialize<Movie>(movieJson, options);

            List<Movie> database = new List<Movie>();
            database.Add(movie);
        }

        [HttpGet]
        public string GetMetadata(int movieId)
        {
            List<Movie> movieList = new List<Movie>();

            var options = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            MovieMap movieMapper = new MovieMap();
            CsvParser<Movie> movieParser = new CsvParser<Movie>(csvParserOptions, movieMapper);
            var movieResult = movieParser.ReadFromFile(@"metadata.csv", Encoding.ASCII).ToList();

            foreach (var details in movieResult)
            {
                if (details.Result.MovieId == movieId)
                {
                    if (movieList.Count == 0)
                    {
                        movieList.Add(details.Result);
                    }
                    else
                    {
                        var mov = movieList.Find(x => x.Language == details.Result.Language);
                        if (mov == null)
                        {
                            movieList.Add(details.Result);
                        }
                        else
                        {
                            if (details.Result.ID > mov.ID)
                            {
                                movieList.Remove(mov);
                                movieList.Add(details.Result);
                            }
                        }
                    }
                }
            }

            movieList.Sort((x, y) => string.Compare(x.Language, y.Language));

            var movieJson = JsonSerializer.Serialize(movieList, options);

            return movieJson;
        }

        [HttpGet]
        public string GetMovieStats()
        {
            List<MovieStats> movieStatsList = new List<MovieStats>();
            List<Movie> movieList = new List<Movie>();
            List<Stat> statList = new List<Stat>();
            Movie mov = new Movie();
            List<Stat> reqStatsList = new List<Stat>();

            var options = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };

            CsvParserOptions csvParserOptions = new CsvParserOptions(true, ',');
            MovieMap movieMapper = new MovieMap();
            CsvParser<Movie> movieParser = new CsvParser<Movie>(csvParserOptions, movieMapper);
            var movieResult = movieParser.ReadFromFile(@"metadata.csv", Encoding.ASCII).ToList();

            foreach (var details in movieResult)
            {
                movieList.Add(details.Result);
            }

            StatMap statMapper = new StatMap();
            CsvParser<Stat> statParser = new CsvParser<Stat>(csvParserOptions, statMapper);
            var statResult = statParser.ReadFromFile(@"stats.csv", Encoding.ASCII).ToList();

            foreach (var details in statResult)
            {
                statList.Add(details.Result);
            }

            List<int> movieIds = movieList.Select(x => x.MovieId).Distinct().ToList();
            foreach (int id in movieIds)
            {
                List<Movie> movs = movieList.FindAll(x => x.MovieId == id);
                mov = movs.First();

                reqStatsList = statList.FindAll(x => x.MovieId == id);

                MovieStats ms = new MovieStats();
                ms.MovieId = mov.MovieId;
                ms.Title = mov.Title;

                int totalDuration = 0;
                foreach (Stat s in reqStatsList)
                {
                    totalDuration = totalDuration + s.WatchDurationMs;
                }
                
                if (reqStatsList.Count == 0)
                {
                    ms.AverageWatchDurationS = 0;
                }
                else
                {
                    ms.AverageWatchDurationS = (totalDuration / reqStatsList.Count) * 60;
                }

                ms.Watches = reqStatsList.Count;
                ms.ReleaseYear = mov.ReleaseYear;

                movieStatsList.Add(ms);
            }

            movieStatsList = movieStatsList.OrderByDescending(x => x.AverageWatchDurationS).ThenByDescending(y => y.ReleaseYear).ToList();

            var movieStatsJson = JsonSerializer.Serialize(movieStatsList, options);

            return movieStatsJson;
        }
    }
}
